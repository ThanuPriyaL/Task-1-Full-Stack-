export default class AppSettings{

      static service_host_url = process.env.REACT_APP_BASE_URL
}