import React from "react";
import { useState } from "react";
import { FaArrowLeft, FaTimes } from "react-icons/fa";
import Sidewindowone from "../administrationsSideWindow/AdministrationWindow";
import Sidewindowtwo from "../AddAdminSideWindow/AddAdminSideWindow";

const Slidewindow = (props) => {
  const [clicked, setclicked] = useState(true);
  return (
    <div className="window" style={{ paddingTop: "70px", paddingLeft: "20px" }}>
      <h5 style={{ paddingLeft: "350px", verticalAlign: "top" }}>
        {" "}
        <a href="/">
          <FaArrowLeft> </FaArrowLeft>{" "}
        </a>
        &nbsp; &nbsp;{" "}
        <a href="/">
          <FaTimes></FaTimes>
        </a>
      </h5>
      <h4
        style={{
          paddingTop: "10px",
          paddingLeft: "10px",
          fontWeight: "bolder",
          fontFamily: "poppins",
        }}
      >
        {props.data}
      </h4>
      <br></br>
      <div className="row">
        <div className="col" style={{ paddingLeft: "20px" }}>
          <tr
            onClick={() => setclicked(true)}
            style={{
              color: "Blue",
              fontFamily: "bold",
              fontWeight: "bolder",
              fontSize: "16px",
              borderBottom: "2px",
            }}
          >
            <h6>Administration</h6>
          </tr>
        </div>
        <div className="col" style={{ paddingRight: "10px" }}>
          <tr
            onClick={() => setclicked(false)}
            style={{
              color: "Blue",
              fontFamily: "bold",
              fontWeight: "bolder",
              fontSize: "16px",
            }}
          >
            <h6>Add Administrator</h6>
          </tr>
        </div>
      </div>
      <div> {clicked ? <Sidewindowone /> : <Sidewindowtwo/>}</div>{" "}
    </div>
  );
};
export default Slidewindow;
