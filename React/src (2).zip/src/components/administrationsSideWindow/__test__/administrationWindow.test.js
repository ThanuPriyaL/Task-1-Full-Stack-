import React from 'react';
import ReactDOM from 'react-dom';
import SideWindowone from '../AdministrationWindow'
import {render, cleanup} from '@testing-library/react'
import Sidewindowone from '../AdministrationWindow';

afterEach(cleanup);

it("renders without crashing", ()=>{
    const div = document.createElement("div");
    ReactDOM.render(<Sidewindowone/>,div)
})
it("renders properly at top of the page", ()=>{
    const {getByTestId} = render(<Sidewindowone />)
    expect(getByTestId('sidewindowone')).toBeVisible(<Sidewindowone/>)
})
it("render table", () =>{
    const {getByTestId} = render(<Sidewindowone/>);
    const input = getByTestId("table");
    expect(input).toBeTruthy();
})
it("render table", () =>{
  const {getByTestId} = render(<Sidewindowone/>);
  const input = getByTestId("tbody");
  expect(input).toBeTruthy();
})