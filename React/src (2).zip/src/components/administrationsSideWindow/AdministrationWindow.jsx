import React, { useState, useEffect } from "react";
import { FaTimes } from "react-icons/fa";
import "./AdministrationWindow.css";
import AdministrationService from "./AdministrationService";
import { logger} from "react-native-logs";
import { toast } from 'react-toastify';

const Sidewindowone = (props) => {
const [admindata, setAdminData] = useState([]);
const [RemoveAdmin, setRemoveAdmin] = useState(
    admindata.empremoveadmin != 0 ? true : false
  );
var log = logger.createLogger();
  useEffect(() => {
    try{
    //Fetching the details
    AdministrationService.retrieveAllAdmins()
      .then((res) => setAdminData(res.data));
      log.info("Retrived all the admins data from the data base");
    }catch{
      log.error("error in fetching the details");
    }
  }, [props]);
  //Removing the Employee as Admininstrator
  const removeAdmin = (empId) => {
    try{
    AdministrationService.removeEmpAdmin(empId)
      .then(setRemoveAdmin(false));
      log.info("successfully removed admin");
      toast.success(` successfully removed admin `);
    }catch{
      log.error("error in updating admin to non admin");
      toast.error(` couldnt update `);
    }
  };
  return (
    <div data-testid="sidewindowone">
      <br></br>
      <br></br>
      <table data-testid="table">
        <tbody data-testid="tbody">
          {admindata.length
            ? admindata.map((adm) => (
                <tr className="tablerow" key={adm.id}>
                  <td
                   className="tabled"
                  >
                    {adm.empId}{" "}
                  </td>
                  <td
                     className="tabled"
                  >
                    {adm.empFirstName}{" "}
                  </td>
                  <td
                    className="tabled"
                  >
                    {adm.empLastName}{" "}
                  </td>
                  <td>
                    <button
                    className="buton"
                      onClick={() => removeAdmin(adm.emp_id)}
                    >
                      <FaTimes />
                    </button>
                  </td>
                </tr>
              ))
            : null}
        </tbody>
      </table>
    </div>
  );
};
export default Sidewindowone;
