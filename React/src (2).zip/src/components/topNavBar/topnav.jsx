import React from "react";
import "./topnav.css";
import a from "../../assets/imgs/others/a.png";

const Topnav=({topnav})=>{
    return (
      <div data-testid="topnav"className="rows">
        <div className="topnav">
          <a className="navbar-brand" href="">
            <img src={a} className="img" height="45px" width="40px" />
          </a>
          <a>
            <p className="pt-3">{topnav}</p>
          </a>
          <a>
            {" "}
            <i id="icon" className="fa fa-user ms-auto" aria-hidden="true"></i>
          </a>
        </div>
      </div>
    );
  }
export default Topnav;
