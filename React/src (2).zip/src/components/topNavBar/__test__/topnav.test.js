import React from 'react';
import ReactDOM from'react-dom';
import Topnav from '../topnav';
import {render , cleanup} from '@testing-library/react'


afterEach(cleanup);

it("renders without crashing", ()=>{
    const div = document.createElement("div");
    ReactDOM.render(<Topnav/>, div)
})

it("renders properly at top of the page", ()=>{
    const {getByTestId} = render(<Topnav />)
    expect(getByTestId('topnav')).toBeVisible(<Topnav/>)
})

it("renders properly heading", ()=>{
    const {getByTestId} = render(< Topnav topnav="ADMINISTRATION"/>)
    expect(getByTestId('topnav')).toHaveTextContent("ADMINISTRATION")
})


