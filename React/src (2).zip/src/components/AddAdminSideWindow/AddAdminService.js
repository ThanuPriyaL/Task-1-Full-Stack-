import axios from 'axios'
import config from  '../../app.settings'
class AddAdminService {
    retrieveAllNonAdmins() {
        // console.log('executed employees with no admin privillages service')
        return axios.get(`${config.service_host_url}/employees/noadmins`);
        
    }
    makeEmpAdmin(empId) {
        console.log('executed Editing a employees admin privillages service')
        return axios.put(`${config.service_host_url}/employees/editempadmin/${empId}`);
    }
}
export default new AddAdminService()