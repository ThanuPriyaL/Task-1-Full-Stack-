import React, { useState, useEffect } from "react";
import { FaSearch,FaCheckCircle } from "react-icons/fa";
import "./AddAdminSideWindow.css";
import AddAdminService from "./AddAdminService";
import { toast } from 'react-toastify';
import { logger} from "react-native-logs";

const Sidewindowtwo = (props) => {
  const [isclickedone, setisclickedone] = useState(false);
  const [empdata, setEmpData] = useState([]);
  const [id, setid] = useState(0);
  const [AddAdmin, setAddAdmin] = useState(
    empdata.emp_admin_privillages != 0 ? true : false
  );
  const [searchTerm, setSearchTerm] = useState("");
  var log = logger.createLogger();
  //Getting the details of Employee
  useEffect(() => {
    try{
    AddAdminService.retrieveAllNonAdmins()
      .then((res) => setEmpData(res.data));
      log.info("Retrived all the non admins data from the data base");
    }catch{
      log.error("error in fetching the details");
    }
  }, [props]);
  //Making Employee as Administrator
  const addAdmin = (empId) => {
    try{
    AddAdminService.makeEmpAdmin(empId)
      .then(setAddAdmin(true));
      log.info("successfully updated non admin to admin");
      
    }catch{
      log.error("error in updating non admin to admin");
      toast.error(` couldnt update `);
    }
  };
  const refresh = () => {
    window.location.reload(false);
    toast.success(` successfully updated as admin`);
  };
  return (
    <div data-testid="button">
      <div className="addadm">
        <h5>who do you want to assign this role?</h5>
        <span className="color">
          <FaSearch />
        </span>
        &nbsp;
        <input
          type="search"
          placeholder="Start typing name or ID"
          onChange={(event) => {
            setSearchTerm(event.target.value);
          }}
        />
      </div>
      <div className="row">
        <div className="column">
          <table data-testid="table">
            <thead data-testid="thead">
              <tr>
                <th
                  className="col-4"
                
                >
                  {" "}
                  Id
                </th>
                <th className="tablehead"> Name</th>
                <th></th>
                <th></th>
              </tr>
            
            </thead>
            <tbody data-testid="tbody">
              {empdata
                .filter((emp) => {
                  if (searchTerm == "") {
                    return emp;
                  } else if (
                    emp.empFirstName
                      .toLowerCase()
                      .includes(searchTerm.toLowerCase()) ||
                    emp.empLastName
                      .toLowerCase()
                      .includes(searchTerm.toLowerCase())
                  ) {
                    return emp;
                  }
                })
                .map((emp) => (
                  <tr
                    onClick={() => {
                      setisclickedone(true);
                      setid(emp.empId);
                    }}
                    style={
                      isclickedone && emp.empId === id
                        ? { backgroundColor: "#ededed" }
                        : null
                    }
                  >
                    <td className="tabledata">
                      {emp.empId}
                    </td>
                    <td
                      className="col"
                    >
                      {emp.empFirstName}&nbsp;{emp.empLastName}
                    </td>
                    <td
                      className="colu"
                      onClick={() => addAdmin(emp.empId)}
                    >
                      {" "}<FaCheckCircle/>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
      <div>
        <button onClick={refresh}>save</button>
      </div>
    </div>
  );
};
export default Sidewindowtwo;
