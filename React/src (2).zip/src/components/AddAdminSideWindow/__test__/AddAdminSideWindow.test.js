import React from 'react';
import ReactDOM from'react-dom';
import  Sidewindowtwo from '../AddAdminSideWindow'
import {render , cleanup,screen} from '@testing-library/react'



afterEach(cleanup);

it("renders without crashing", ()=>{
    const div = document.createElement("div");
    ReactDOM.render(<Sidewindowtwo/>, div)
})

it("renders properly on the page", ()=>{
    const {getByTestId} = render(< Sidewindowtwo/>)
    expect(getByTestId('button')).toBeVisible(< Sidewindowtwo/>)
})
test('render a element', () => {
    render(<Sidewindowtwo />);
    expect(screen.getByText('Name')).toBeInTheDocument();
  });
it("render table", () =>{
    const {getByTestId} = render(<Sidewindowtwo/>);
    const input = getByTestId("table");
    expect(input).toBeTruthy();
})
it("render table", () =>{
    const {getByTestId} = render(<Sidewindowtwo/>);
    const input = getByTestId("thead");
    expect(input).toBeTruthy();
})
it("render table", () =>{
  const {getByTestId} = render(<Sidewindowtwo/>);
  const input = getByTestId("tbody");
  expect(input).toBeTruthy();
})
// it('test font size', () => {
//     const wrapper = render(<Sidewindowtwo/>);
//     expect(wrapper.find('h1')).toHaveStyleRule('font-size', '20px');
//   });