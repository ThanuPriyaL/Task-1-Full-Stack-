import React from "react";
// import "../Css/App.css";
import "./dashboardWindow.css";
import logo from "../../assets/imgs/others/logo.png";
import ss from "../../assets/imgs/others/ss.png";
import s2 from "../../assets/imgs/others/s2.png";
import side from "../../assets/imgs/others/side.png";

function Sidebar({Sidebar}) {
  return (
    <div data-testid="topnav">
      <div className="row">
        <nav id="sidebar">
          <ul className="list-unstyled components">
            <li>
              <a >
                <i className="fa fa-home ml-3 mr-2 mt-4" aria-hidden="true"></i>Home
              </a>
            </li>
            <li className="active">
              <a
                data-toggle="collapse"
                aria-expanded="false"
              >
                <i className="fas fa-user-friends ml-3 mr-2"></i>
                Users
                <i id="drop" className="fas fa-angle-down"></i>
              </a>
              <ul className="collapse list-unstyled ml-4" id="homeSubmenu">
                <li>
                  <a >Contact</a>
                </li>
                <li>
                  <a >Deleted Users</a>
                </li>
                <li>
                  <a>Users settings</a>
                </li>
              </ul>
            </li>
            <li>
              <a
                data-toggle="collapse"
                aria-expanded="false"
              >
                <i className="fas fa-users ml-3 mr-2"></i>
                Groups
                <i id="drop" className="fas fa-angle-down"></i>
              </a>
            </li>
            <li>
              <a>
                <i className="fas fa-user-plus ml-3 mr-2"></i>Roles
              </a>
            </li>
            <li className="active">
              <a
                href="#settingsSubmenu"
                data-toggle="collapse"
                aria-expanded="false"
              >
                <i className="fa fa-cog ml-3 mr-2" aria-hidden="true"></i>
                Settings
                <i id="drop" className="fas fa-angle-down"></i>
              </a>
              <ul className="collapse list-unstyled ml-3 mr-2" id="settingsSubmenu">
                <li>
                  <a href="/">
                    <img  data-testid="mark" src={side} width="6" height="20" />
                    &nbsp;{Sidebar}
                  </a>
                </li>
              </ul>
            </li>
          </ul>
          <ul className="list-unstyled ml-3 mr-2">
            <li>
              <a href="/">
                <img
                  data-testid="icon"
                  src={ss}
                  width="15"
                  height="15"
                  // class="fix"
                  alt=""
                />{" "}
                &nbsp;Apps admin centers
              </a>
            </li>
            <li>
              <a>
                <img
                 data-testid="icons"
                  src={s2}
                  width="20"
                  height="20"
                  // class="fix"
                  alt=""
                />{" "}
                &nbsp;Impersonate user
              </a>
            </li>
          </ul>
          <img  data-testid="logo" src={logo} width="210" height="80" className="fix" alt="" />
        </nav>
      </div>
    </div>
  );
}
export default Sidebar;
