import React from 'react';
import ReactDOM from'react-dom';
import Sidebar from '../dashboardWindow';
import {render , cleanup, screen, getByTestId} from '@testing-library/react'

afterEach(cleanup);

it("renders without crashing", ()=>{
    const div = document.createElement("div");
    ReactDOM.render(<Sidebar/>, div)
})

it("renders properly at top of the page", ()=>{
    const {getByTestId} = render(<Sidebar />)
    expect(getByTestId('topnav')).toBeVisible(<Sidebar/>)
})
it("renders properly heading", ()=>{
    const {getByTestId} = render(<Sidebar Sidebar="Integrated apps"/>)
    expect(getByTestId('topnav')).toHaveTextContent("Integrated apps")
})
test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Home')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Users')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Contact')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Deleted Users')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Users settings')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Groups')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Roles')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Settings')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Apps admin centers')).toBeInTheDocument();
  });
  test('render a element', () => {
    render(<Sidebar />);
    expect(screen.getByText('Impersonate user')).toBeInTheDocument();
  });
  // test('render a element', () => {
  //   render(<Sidebar />);
  //   expect(getByTestId('mark')).not.toHaveAccessibleDescription();
  // });
  // test('render a element', () => {
  //   render(<Sidebar />);
  //   expect(getByTestId('icon')).not.toHaveAccessibleDescription();
  // });
  // test('render a element', () => {
  //   render(<Sidebar />);
  //   expect(getByTestId('icons')).not.toHaveAccessibleDescription();
  // });
  // test('render a element', () => {
  //   render(<Sidebar />);
  //   expect(getByTestId('logo')).not.toHaveAccessibleDescription();
  // });