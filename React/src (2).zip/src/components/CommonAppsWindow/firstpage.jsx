import React from "react";
import Sidebar from "../dashboardWindow/dashboardWindow";
import Apps from "../integratedAppsWindow/integratedApps";
const Firstpage=()=> {
    return (
      <div>
        <div className="rows">
          <div className="column1">
            <Sidebar Sidebar="Integrated apps"></Sidebar>
          </div>
          <div className="column2">
            <Apps/>
          </div>
        </div>
      </div>
    );
  }
export default Firstpage;
