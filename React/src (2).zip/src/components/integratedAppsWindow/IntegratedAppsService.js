import axios from 'axios'
import config from  '../../app.settings'
const BASE_API_URL = 'http://localhost:8080'
class IntegratedAppsServices {
    retrieveAllApps() {
        // console.log('executed Retriving all the non admins service')
        return axios.get(`${config.service_host_url}/apps`);
    }
}
export default new IntegratedAppsServices()