import React, {useEffect, useState } from "react";
import { logger} from "react-native-logs";
import { toast } from 'react-toastify';
import "./integratedApps.css";

import {
  FaArrowUp,
  FaGreaterThan,
  FaSearch,
  FaBars,
  FaCheckCircle,
} from "react-icons/fa";
import Slidewindow from "../CommonSideWindow/Slidewindow";
import IntegratedAppsService from "./IntegratedAppsService";
const Apps = (app) => {
  const [appdata, setAppData] = useState([]);
  const [appName, setappName] = useState(0);
  const [isclicked, setisclicked] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  var log = logger.createLogger();
  
  useEffect(() => {
    try{
    IntegratedAppsService.retrieveAllApps()
    .then((res) => setAppData(res.data));
    log.info("Retrived all the apps data from the data base");
    toast.success(` apps fetched successsfully `);
  }
    catch{
      log.error("error in fetching the details");
    }
  }, []);
  
  return (
    <div data-testid="app" className="top">
      <div className="loc">
        <p className="smaller">
          Settings{" "}
          <FaGreaterThan  className="icon"/>{" "}
          Integrated Apps
        </p>
        <h3 className="small">Integrated apps</h3>
      </div>
      <div className="roows">
        <span className="span">
          <FaBars />
        </span>
        <span className="span">
          <input
            type="text"
            placeholder="Search apps list"
            onChange={(event) => {
              setSearchTerm(event.target.value);
            }}
          />
        </span>
        <span className="spann">
          <FaSearch />
        </span>
      </div>
      <div className="row">
        <div className="column">
          <div className="roow">
            <table data-testid="table" >
              <thead data-testid="thead">
                <tr>
                  <th></th>
                  <th></th>
                  <th className="th">
                    Apps Name<FaArrowUp></FaArrowUp>
                  </th>
                  <th className="th">
                    Description
                  </th>
                  <th className="th">
                    Status
                  </th>
                  <th></th>
                </tr>
              </thead>
              <tbody data-testid="tbody">
                {appdata
                  .filter((ob) => {
                    if (searchTerm == "") {
                      return ob;
                    } else if (
                      ob.appName
                        .toLowerCase()
                        .includes(searchTerm.toLowerCase())
                    ) {
                      return ob;
                    }
                  })
                  .map((ob) => (
                    <tr
                      onClick={() => {
                        setisclicked(true);
                        setappName(ob.appName);
                      }}
                      style={
                        isclicked && ob.appName === appName
                          ? { backgroundColor: "#ededed" }
                          : null
                      }
                    >
                      <td>
                        {" "}
                        {isclicked && ob.appName === appName ? (
                          <FaCheckCircle
                            style={{ color: "blue" }}
                          ></FaCheckCircle>
                        ) : null}
                      </td>
                      <td className="tdd">
                        <img
                          src={ob.appImg}
                          height="20px"
                          width="20px"
                          alt={ob.appName}
                        ></img>
                      </td>
                      <td className="td1">
                        {ob.appName}
                      </td>
                      <td className="td2">
                        {ob.description}
                      </td>
                      <td className="td3">
                        {ob.status}
                      </td>
                      <td className="td4">
                        <img
                          src={ob.statusImg}
                          height="20px"
                          alt={ob.status}
                        ></img>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {isclicked ? (
        <div className="activeuserdetails">
          <Slidewindow data={appName}></Slidewindow>
        </div>
      ) : null}
    </div>
  );
};

export default Apps;