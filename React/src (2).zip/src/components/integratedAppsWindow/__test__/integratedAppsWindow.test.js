import React from 'react';
import ReactDOM from'react-dom';
import Apps from '../integratedApps'
import {render , cleanup, screen} from '@testing-library/react'


afterEach(cleanup);

it("renders without crashing", ()=>{
    const div = document.createElement("div");
    ReactDOM.render(<Apps/>, div)
})

it("renders properly on the page", ()=>{
    const {getByTestId} = render(<Apps />)
    expect(getByTestId('app')).toBeVisible(<Apps/>)
})
test('render h3 element', () => {
    render(<Apps />);
    expect(screen.getByText('Integrated apps')).toBeInTheDocument();
  });
test('render th element', () => {
    render(<Apps />);
    expect(screen.getByText('Apps Name')).toBeInTheDocument();
  });
  test('render th element', () => {
    render(<Apps />);
    expect(screen.getByText('Description')).toBeInTheDocument();
  });
  test('render th element', () => {
    render(<Apps />);
    expect(screen.getByText('Status')).toBeInTheDocument();
  });
  it("render table", () =>{
    const {getByTestId} = render(<Apps/>);
    const input = getByTestId("table");
    expect(input).toBeTruthy();
})
it("render table", () =>{
  const {getByTestId} = render(<Apps/>);
  const input = getByTestId("thead");
  expect(input).toBeTruthy();
})
it("render table", () =>{
  const {getByTestId} = render(<Apps/>);
  const input = getByTestId("tbody");
  expect(input).toBeTruthy();
})