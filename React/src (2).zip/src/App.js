
import './App.css';
import Firstpage from './components/CommonAppsWindow/firstpage';
import Topnav from './components/topNavBar/topnav';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'
function App() {
  return (
    <div className="App">
      <Topnav topnav="ADMINISTRATION"></Topnav>
      <Firstpage/>
      <ToastContainer autoClose={2000}  />
    </div>
  );
}

export default App;
