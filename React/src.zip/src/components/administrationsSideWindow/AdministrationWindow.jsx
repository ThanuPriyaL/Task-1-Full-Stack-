import React, { useState, useEffect } from "react";
import axios from "axios";
import { FaTimes } from "react-icons/fa";
import "./AdministrationWindow.css";
import AdministrationService from "./AdministrationService";

const Sidewindowone = (props) => {
const [admindata, setAdminData] = useState([]);
const [RemoveAdmin, setRemoveAdmin] = useState(
    admindata.empremoveadmin != 0 ? true : false
  );
  useEffect(() => {
    //Fetching the details
    AdministrationService.retrieveAllAdmins()
      .then((res) => setAdminData(res.data));
  }, [props]);
  //Removing the Employee as Admininstrator
  const removeAdmin = (empId) => {
    AdministrationService.removeEmpAdmin(empId)
      .then(setRemoveAdmin(false));
  };
  return (
    <div>
      <br></br>
      <br></br>
      <table>
        <tbody>
          {admindata.length
            ? admindata.map((adm) => (
                <tr className="tablerow" key={adm.id}>
                  <td
                   className="tabled"
                  >
                    {adm.empId}{" "}
                  </td>
                  <td
                     className="tabled"
                  >
                    {adm.empFirstName}{" "}
                  </td>
                  <td
                    className="tabled"
                  >
                    {adm.empLastName}{" "}
                  </td>
                  <td>
                    <button
                    className="buton"
                      onClick={() => removeAdmin(adm.empId)}
                    >
                      <FaTimes />
                    </button>
                  </td>
                </tr>
              ))
            : null}
        </tbody>
      </table>
    </div>
  );
};
export default Sidewindowone;
