import React, { useState, useEffect } from "react";
import { FaSearch,FaCheckCircle } from "react-icons/fa";
import "./AddAdminSideWindow.css";
import AddAdminService from "./AddAdminService";

const Sidewindowtwo = (props) => {
  const [isclickedone, setisclickedone] = useState(false);
  const [empdata, setEmpData] = useState([]);
  const [id, setid] = useState(0);
  const [AddAdmin, setAddAdmin] = useState(
    empdata.emp_admin_privillages != 0 ? true : false
  );
  const [searchTerm, setSearchTerm] = useState("");
  //Getting the details of Employee
  useEffect(() => {
    AddAdminService.retrieveAllNonAdmins()
      .then((res) => setEmpData(res.data));
  }, [props]);
  //Making Employee as Administrator
  const addAdmin = (empId) => {
    AddAdminService.makeEmpAdmin(empId)
      .then(setAddAdmin(true));
  };
  const refresh = () => {
    window.location.reload(false);
  };
  return (
    <div>
      <div className="addadm">
        <h5>who do you want to assign this role?</h5>
        <span className="color">
          <FaSearch />
        </span>
        &nbsp;
        <input
          type="search"
          placeholder="Start typing name or ID"
          onChange={(event) => {
            setSearchTerm(event.target.value);
          }}
        />
      </div>
      <div class="row">
        <div class="column">
          <br></br>
          <table>
            <thead>
              <tr>
                <th
                  class="col-4"
                
                >
                  {" "}
                  Id
                </th>
                <th className="tablehead"> Name</th>
                <th></th>
                <th></th>
              </tr>
              <br></br>
            </thead>
            <tbody>
              {empdata
                .filter((emp) => {
                  if (searchTerm == "") {
                    return emp;
                  } else if (
                    emp.empFirstName
                      .toLowerCase()
                      .includes(searchTerm.toLowerCase()) ||
                    emp.empLastName
                      .toLowerCase()
                      .includes(searchTerm.toLowerCase())
                  ) {
                    return emp;
                  }
                })
                .map((emp) => (
                  <tr
                    onClick={() => {
                      setisclickedone(true);
                      setid(emp.empId);
                    }}
                    style={
                      isclickedone && emp.empId === id
                        ? { backgroundColor: "#ededed" }
                        : null
                    }
                  >
                    <td className="tabledata">
                      {emp.empId}
                    </td>
                    <td
                      class="col"
                    >
                      {emp.empFirstName}&nbsp;{emp.empLastName}
                    </td>
                    <td
                      class="colu"
                      onClick={() => addAdmin(emp.empId)}
                    >
                      {" "}<FaCheckCircle/>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
      <div>
        <button onClick={refresh}>Save</button>
      </div>
    </div>
  );
};
export default Sidewindowtwo;
