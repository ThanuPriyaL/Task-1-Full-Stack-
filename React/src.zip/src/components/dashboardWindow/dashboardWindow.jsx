import React from "react";
// import "../Css/App.css";
import "./dashboardWindow.css";
import logo from "../../assets/imgs/others/logo.png";
import ss from "../../assets/imgs/others/ss.png";
import s2 from "../../assets/imgs/others/s2.png";
import side from "../../assets/imgs/others/side.png";

function Sidebar() {
  return (
    <div>
      <div className="row">
        <nav id="sidebar">
          <ul class="list-unstyled components">
            <li>
              <a >
                <i class="fa fa-home ml-3 mr-2 mt-4" aria-hidden="true"></i>Home
              </a>
            </li>
            <li class="active">
              <a
                data-toggle="collapse"
                aria-expanded="false"
              >
                <i class="fas fa-user-friends ml-3 mr-2"></i>
                users
                <i id="drop" class="fas fa-angle-down"></i>
              </a>
              <ul class="collapse list-unstyled ml-4" id="homeSubmenu">
                <li>
                  <a >Contact</a>
                </li>
                <li>
                  <a >Deleted Users</a>
                </li>
                <li>
                  <a>Users settings</a>
                </li>
              </ul>
            </li>
            <li>
              <a
                data-toggle="collapse"
                aria-expanded="false"
              >
                <i class="fas fa-users ml-3 mr-2"></i>
                Groups
                <i id="drop" class="fas fa-angle-down"></i>
              </a>
            </li>
            <li>
              <a>
                <i class="fas fa-user-plus ml-3 mr-2"></i>Roles
              </a>
            </li>
            <li class="active">
              <a
                href="#settingsSubmenu"
                data-toggle="collapse"
                aria-expanded="false"
              >
                <i class="fa fa-cog ml-3 mr-2" aria-hidden="true"></i>
                Settings
                <i id="drop" class="fas fa-angle-down"></i>
              </a>
              <ul class="collapse list-unstyled ml-3 mr-2" id="settingsSubmenu">
                <li>
                  <a href="/">
                    <img src={side} width="6" height="20" />
                    &nbsp;Integrated apps
                  </a>
                </li>
              </ul>
            </li>
          </ul>
          <ul class="list-unstyled ml-3 mr-2">
            <li>
              <a href="/">
                <img
                  src={ss}
                  width="15"
                  height="15"
                  // class="fix"
                  alt=""
                />{" "}
                &nbsp;Apps admin centers
              </a>
            </li>
            <li>
              <a>
                <img
                  src={s2}
                  width="20"
                  height="20"
                  // class="fix"
                  alt=""
                />{" "}
                &nbsp;Impersonate user
              </a>
            </li>
          </ul>
          <img src={logo} width="210" height="80" class="fix" alt="" />
        </nav>
      </div>
    </div>
  );
}
export default Sidebar;
