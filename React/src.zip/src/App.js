
import './App.css';
import Firstpage from './components/CommonAppsWindow/firstpage';
import Topnav from './components/topNavBar/topnav';
function App() {
  return (
    <div className="App">
      <Topnav></Topnav>
      <Firstpage/>
          
    </div>
  );
}

export default App;
