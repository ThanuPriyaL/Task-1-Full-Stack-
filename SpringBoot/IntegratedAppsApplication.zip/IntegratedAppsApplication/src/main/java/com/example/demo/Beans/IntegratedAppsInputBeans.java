package com.example.demo.Beans;

public class IntegratedAppsInputBeans {
	private String appName;
	
	private String appImg;
	private String description;
	private String status;
	private String statusImg;
	
	public IntegratedAppsInputBeans() {}
	
	public IntegratedAppsInputBeans(String appName, String appImg, String description, String status, String statusImg) {
		super();
		this.appName = appName;
		this.appImg = appImg;
		this.description = description;
		this.status = status;
		this.statusImg = statusImg;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppImg() {
		return appImg;
	}

	public void setAppImg(String appImg) {
		this.appImg = appImg;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusImg() {
		return statusImg;
	}

	public void setStatusImg(String statusImg) {
		this.statusImg = statusImg;
	}

	@Override
	public String toString() {
		return "IntegratedAppsBeans [appName=" + appName + ", appImg=" + appImg + ", description=" + description
				+ ", status=" + status + ", statusImg=" + statusImg + "]";
	}
	
}
