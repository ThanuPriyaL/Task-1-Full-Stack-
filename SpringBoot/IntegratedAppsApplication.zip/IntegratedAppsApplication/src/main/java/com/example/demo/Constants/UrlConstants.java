package com.example.demo.Constants;

public interface UrlConstants {
	
	public String CROSS_ORIGIN_URL="http://localhost:3000";
	
	public String INTEGRATED_APPS_URL="/apps";
	
	public String EMPLOYEE_ADMIN_URL="/employees/admins";
	
	public String EMPLOYEE_NONADMIN_URL="/employees/noadmins";
	
	public String EMPLOYEE_EDITADMINPRIV_URL="/employees/editempadmin/{empId}";

}
