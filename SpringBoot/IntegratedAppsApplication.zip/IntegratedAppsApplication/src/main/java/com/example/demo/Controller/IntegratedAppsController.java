package com.example.demo.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Constants.LoggerMessages;
import com.example.demo.Constants.UrlConstants;
import com.example.demo.Entity.IntegratedApps;
//import com.example.demo.Model.IntegratedAppsModel;
import com.example.demo.Service.IntegratedAppsService;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataAccessException;


@RestController
@CrossOrigin(origins= {UrlConstants.CROSS_ORIGIN_URL})
public class IntegratedAppsController {
	
private static final Logger LOGGER=LoggerFactory.getLogger(IntegratedAppsController.class);

@Autowired
IntegratedAppsService integratedAppsService;

@GetMapping( value = {UrlConstants.INTEGRATED_APPS_URL} ,produces = MediaType.APPLICATION_JSON_VALUE )
public ResponseEntity<List<IntegratedApps>> getIntegratedAppsModel()
{
	
		LOGGER.info("Initializing Integrated Apps data from server.....");
		List<IntegratedApps> list=integratedAppsService.getIntegratedApps();
		if(list==null) {
			LOGGER.info(LoggerMessages.UNSUCCESSFUL_FETCHING_APPS_MSG);
			return null;
		}
		else {
		LOGGER.info(LoggerMessages.SUCCESSFULLY_FETCHED_APPS_MSG);
		return new ResponseEntity<List<IntegratedApps>>(list,HttpStatus.OK);

		}
	}
}