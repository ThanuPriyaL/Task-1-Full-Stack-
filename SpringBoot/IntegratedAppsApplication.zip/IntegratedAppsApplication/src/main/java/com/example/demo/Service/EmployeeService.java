package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Beans.EmployeeInputBean;
import com.example.demo.Constants.LoggerMessages;
import com.example.demo.Controller.EmployeeController;
import com.example.demo.Entity.Employee;
//import com.example.demo.Beans.EmployeeInputBean;
//import com.example.demo.Entity.Employee;
import com.example.demo.Model.EmployeeModel;
import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataAccessException;

@Service
public class EmployeeService {
@Autowired
EmployeeRepository employeeRepository;
private static final Logger LOGGER=LoggerFactory.getLogger(EmployeeController.class);

public List<Employee> getByAdminPriv(){
	
	try {
List<EmployeeInputBean>adminList=new ArrayList<>();

List<Employee>employees=employeeRepository.findAllEmployeeByAdminPriv();

for(Employee employee:employees) {
EmployeeInputBean employeeinputbean=new EmployeeInputBean();

employeeinputbean.setEmpId(employee.getEmpId());
employeeinputbean.setEmpFirstName(employee.getEmpFirstName());
employeeinputbean.setEmpLastName(employee.getEmpLastName());
employeeinputbean.setEmpAdminPrivillages(employee.getEmpAdminPrivillages());
adminList.add(employeeinputbean);
}
LOGGER.info(LoggerMessages.SUCCESS_MESSAGE);
return employees;
	}
catch(BadRequestException e) {
	throw new BadRequestException(LoggerMessages.BAD_REQUEST,e);
	}
		catch(DataAccessException e) {
			throw new DataAccessException(LoggerMessages.DATA_ACCESS_ERROR_MSG,e);
	}
}

public List<Employee> getByNoAdminPriv(){
	try {
List<EmployeeInputBean>adminList=new ArrayList<>();

List<Employee>employees=employeeRepository.findAllEmployeeByNoAdminPriv();

for(Employee employee:employees) {
EmployeeInputBean employeeinputbean=new EmployeeInputBean();

employeeinputbean.setEmpId(employee.getEmpId());
employeeinputbean.setEmpFirstName(employee.getEmpFirstName());
employeeinputbean.setEmpLastName(employee.getEmpLastName());
employeeinputbean.setEmpAdminPrivillages(employee.getEmpAdminPrivillages());
adminList.add(employeeinputbean);
}
LOGGER.info(LoggerMessages.SUCCESS_MESSAGE);
return employees;
}
	catch(BadRequestException e) {
		throw new BadRequestException(LoggerMessages.BAD_REQUEST,e);
		}
			catch(DataAccessException e) {
				throw new DataAccessException(LoggerMessages.DATA_ACCESS_ERROR_MSG,e);
		}
}

public void editAdminPriv(int empId)
{
	try {
System.out.print(empId);

	    Employee emp= employeeRepository.getById(empId);
	    if(emp.getEmpAdminPrivillages()==0)
	    {
	        emp.setEmpAdminPrivillages(1);
	    }
	    else
	    {
	        emp.setEmpAdminPrivillages(0);
	    }
	  
	    employeeRepository.save(emp);
	LOGGER.info(LoggerMessages.SUCCESS_MESSAGE);
	}
	catch(BadRequestException e) {
		throw new BadRequestException(LoggerMessages.BAD_REQUEST,e);
		}
			catch(DataAccessException e) {
				throw new DataAccessException(LoggerMessages.DATA_ACCESS_ERROR_MSG,e);
		}
}
}

