package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Beans.IntegratedAppsInputBeans;
import com.example.demo.Constants.LoggerMessages;
import com.example.demo.Controller.EmployeeController;
import com.example.demo.Entity.IntegratedApps;
//import com.example.demo.Model.IntegratedAppsModel;
import com.example.demo.Repository.IntegratedAppsRepository;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataAccessException;


@Service
public class IntegratedAppsService {
@Autowired
IntegratedAppsRepository integratedappsrepository;
private static final Logger LOGGER=LoggerFactory.getLogger(EmployeeController.class);


//public List<IntegratedAppsModel> getIntegratedApps() {
//
//List<IntegratedAppsModel> list=integratedappsrepository.findAll();
//
//return list;
//}

public List<IntegratedApps> getIntegratedApps() {
		
List<IntegratedAppsInputBeans>appList=new ArrayList<>();

List<IntegratedApps>list=integratedappsrepository.findAll();

for(IntegratedApps apps:list) {
	IntegratedAppsInputBeans intergartedsappinputbean=new IntegratedAppsInputBeans();
	 intergartedsappinputbean.setAppName(apps.getAppName());
	 intergartedsappinputbean.setAppImg(apps.getAppImg());
	 intergartedsappinputbean.setDescription(apps.getDescription());
	 intergartedsappinputbean.setStatus(apps.getStatus());
	 intergartedsappinputbean.setStatusImg(apps.getStatusImg());
appList.add( intergartedsappinputbean);
}
LOGGER.info(LoggerMessages.SUCCESS_MESSAGE);
return list;
}
}