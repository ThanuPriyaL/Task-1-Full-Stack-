package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegratedAppsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegratedAppsApplication.class, args);
	}

}
