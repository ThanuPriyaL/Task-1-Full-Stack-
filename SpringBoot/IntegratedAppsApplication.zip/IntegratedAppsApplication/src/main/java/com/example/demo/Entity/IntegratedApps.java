package com.example.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table
public class IntegratedApps {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private String appName;
	
	private String appImg;
	private String description;
	private String status;
	private String statusImg;
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppImg() {
		return appImg;
	}
	public void setAppImg(String appImg) {
		this.appImg = appImg;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusImg() {
		return statusImg;
	}
	public void setStatusImg(String statusImg) {
		this.statusImg = statusImg;
	}
	
	
	
	
}