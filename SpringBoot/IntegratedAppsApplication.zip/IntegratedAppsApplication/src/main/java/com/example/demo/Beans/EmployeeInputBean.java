package com.example.demo.Beans;

public class EmployeeInputBean {
	private int empId;

	private String empFirstName;
	private String empLastName;
	private int empAdminPrivillages;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public int getEmpAdminPrivillages() {
		return empAdminPrivillages;
	}
	public void setEmpAdminPrivillages(int empAdminPrivillages) {
		this.empAdminPrivillages = empAdminPrivillages;
	}
	public EmployeeInputBean() {}
	public EmployeeInputBean(int empId, String empFirstName, String empLastName, int empAdminPrivillages) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empAdminPrivillages = empAdminPrivillages;
	}
	
	@Override
	public String toString() {
		return "EmployeeInputBean [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empAdminPrivillages=" + empAdminPrivillages + "]";
	}
	

}
