package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.Employee;
import com.example.demo.Model.EmployeeModel;



@Repository
public  interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	@Query(nativeQuery = true, value="select * from employees where emp_Admin_Privillages=1")
    List<Employee> findAllEmployeeByAdminPriv();
    @Query(nativeQuery = true, value="select * from employees where emp_Admin_Privillages=0")
    List<Employee> findAllEmployeeByNoAdminPriv();
	
    
}




