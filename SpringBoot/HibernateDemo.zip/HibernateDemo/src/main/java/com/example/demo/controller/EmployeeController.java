package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.constants.LoggerMessages;
import com.example.demo.constants.UrlConstants;
import com.example.demo.exception.BadRequestException;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@RestController
@CrossOrigin(origins = { UrlConstants.CROSS_ORIGIN_URL })
public class EmployeeController {
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeController.class);
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@GetMapping(value = { UrlConstants.EMPLOYEE_ADMIN_URL }, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> getAllUsers() {
		try {
			LOGGER.info("Initialix=zing Integrated Apps data frpm server..");
			LOGGER.info(LoggerMessages.SUCCESSFULLY_FETCHED_ADMINS_MSG);
			return employeeRepository.findAllEmployeeByAdminPriv();
	}catch (NullPointerException e) {
		LOGGER.info(LoggerMessages.UNSUCCESSFUL_FETCHING_APPS_MSG);
		throw new NullPointerException(LoggerMessages.NULL_POINTER_ERROR_MSG);
	} catch (BadRequestException e) {
		LOGGER.info(LoggerMessages.BAD_REQUEST);
		throw new BadRequestException(LoggerMessages.BAD_REQUEST, e);
	}
 }
	@GetMapping(value = {UrlConstants.EMPLOYEE_NONADMIN_URL }, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> findAllEmployeeByNoAdminPriv() {
		try {
			LOGGER.info("Initialix=zing Integrated Apps data frpm server..");
			LOGGER.info(LoggerMessages.SUCCESSFULLY_FETCHED_NONADMIN_MSG);
			return employeeRepository.findAllEmployeeByAdminPriv();
	}catch (NullPointerException e) {
		LOGGER.info(LoggerMessages.UNSUCCESSFUL_FETCHING_APPS_MSG);
		throw new NullPointerException(LoggerMessages.NULL_POINTER_ERROR_MSG);
	} catch (BadRequestException e) {
		LOGGER.info(LoggerMessages.BAD_REQUEST);
		throw new BadRequestException(LoggerMessages.BAD_REQUEST, e);
	}
 }
	@PutMapping(value = {UrlConstants.EMPLOYEE_EDITADMINPRIV_URL }, produces = MediaType.APPLICATION_JSON_VALUE)
	public  void editAdminPriv(@PathVariable int empId) {
		try {
			LOGGER.info("Initializing Editing Admin Employees data from server.....");
			System.out.print(empId);
			employeeRepository.editAdminPriv(empId);
	}catch (NullPointerException e) {
		LOGGER.info(LoggerMessages.SUCCESSFULLY_EDITED_ADMINS_MSG);
		throw new NullPointerException(LoggerMessages.NULL_POINTER_ERROR_MSG);
	} catch (BadRequestException e) {
		LOGGER.info(LoggerMessages.BAD_REQUEST);
		throw new BadRequestException(LoggerMessages.BAD_REQUEST, e);
	}
 }
	
}