package com.example.demo.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Employee;
import com.example.demo.model.IntegratedApps;

@Repository
@Transactional
@EnableAutoConfiguration(exclude=HibernateJpaAutoConfiguration.class)
public class IntegratedAppsRepository {
	@Autowired
	private SessionFactory factory;

	public void saveApps(IntegratedApps integratedApps) {
		getSession().save(integratedApps);
	}

	@SuppressWarnings("unchecked")
	public List<IntegratedApps> getApps() {
		return getSession().createCriteria(IntegratedApps.class).list();
	}

	private Session getSession() {
		Session session = factory.getCurrentSession();
		if (session == null) {
			session = factory.openSession();
		}
		return session;
	}
}
