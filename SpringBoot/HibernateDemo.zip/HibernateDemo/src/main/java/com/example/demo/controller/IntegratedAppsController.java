package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.constants.UrlConstants;
import com.example.demo.model.Employee;
import com.example.demo.model.IntegratedApps;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.IntegratedAppsRepository;

@RestController
@CrossOrigin(origins = { UrlConstants.CROSS_ORIGIN_URL })
public class IntegratedAppsController {
	@Autowired
	private IntegratedAppsRepository intergratedAppsRepository;
	
	@PostMapping("/saveApps")
	public String saveApps(@RequestBody IntegratedApps intergratedApps){
		intergratedAppsRepository.saveApps(intergratedApps);
		return "success";
	}
	@GetMapping(value = { UrlConstants.INTEGRATED_APPS_URL }, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<IntegratedApps> getAllApps(){
		return intergratedAppsRepository.getApps();
	}

}
