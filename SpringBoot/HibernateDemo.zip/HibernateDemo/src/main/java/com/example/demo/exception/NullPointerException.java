package com.example.demo.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND)

public class NullPointerException extends RuntimeException {
public  NullPointerException (String message, Integer id) {
super(message);
}



public  NullPointerException (String  NullPointerExceptionMessage, Exception e) {
super( NullPointerExceptionMessage);
}



}

