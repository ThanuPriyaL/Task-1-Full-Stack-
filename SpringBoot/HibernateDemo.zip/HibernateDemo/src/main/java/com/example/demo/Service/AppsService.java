//package com.example.demo.Service;
//
//import java.util.List;
//
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.example.demo.model.ApplicationAccess;
//
//@Transactional
//@EnableAutoConfiguration(exclude=HibernateJpaAutoConfiguration.class)
//public class AppsService {
//	@Autowired
//	private SessionFactory factory;
//
//	public void saveApps(ApplicationAccess apps) {
//		getSession().save(apps);
//	}
//
//	@SuppressWarnings("unchecked")
//	public List<ApplicationAccess> getApps() {
//		return getSession().createCriteria(ApplicationAccess.class).list();
//	}
//
//	private Session getSession() {
//		Session session = factory.getCurrentSession();
//		if (session == null) {
//			session = factory.openSession();
//		}
//		return session;
//	}
//
//}
