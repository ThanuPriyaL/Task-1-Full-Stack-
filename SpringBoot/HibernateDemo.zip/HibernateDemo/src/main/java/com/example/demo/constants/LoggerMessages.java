package com.example.demo.constants;

public interface LoggerMessages {

String SUCCESS="SUCCESS";
String FAILURE="FAILURE";

int INTERNAL_SERVER_ERROR=500;

String BAD_REQUEST="The request was unsuccessful";

String DATA_ACCESS_ERROR_MSG="Unable to Fetch data From server";

String NULL_POINTER_ERROR_MSG="Data Requested is Null";

String REQUEST_TIMEOUT_ERROR_MSG="Request Time Out";

String INTERNAL_SERVER_ERROR_MSG="Something went wrong";

String SUCCESSFULLY_FETCHED_NONADMIN_MSG="Non Admins retrived Successfully";

String SUCCESSFULLY_FETCHED_APPS_MSG="Applications retrived Successfully";

String SUCCESSFULLY_FETCHED_ADMINS_MSG="Admins retrived Successfully";

String SUCCESSFULLY_EDITED_ADMINS_MSG="Admins retrived Successfully";

String EXCEPTIONS_MSG="Exception occured in method";

String UNSUCCESSFUL_FETCHING_APPS_MSG="Couldn't retrieve the requested data, no data found";

public String SUCCESS_MESSAGE = "The request was successful.";

public String ERROR_MESSAGE = "The input data was not valid.";





}
