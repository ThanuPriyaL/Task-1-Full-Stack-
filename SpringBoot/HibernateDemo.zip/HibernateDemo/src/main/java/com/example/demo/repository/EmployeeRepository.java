package com.example.demo.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Employee;


@Repository
@Transactional
@EnableAutoConfiguration(exclude=HibernateJpaAutoConfiguration.class)

public class EmployeeRepository {
	@Autowired
	private SessionFactory factory;

	@SuppressWarnings("unchecked")
	public List<Employee> findAllEmployeeByAdminPriv() {
		return getSession().createCriteria(Employee.class).list();
	}
	
	@SuppressWarnings("unchecked")
	public List<Employee> findAllEmployeeByNoAdminPriv() {
		String query= "select e from Employee e where e.emp_admin_privillages=0";
		return getSession().createSQLQuery(query).list();
	}
	
	@SuppressWarnings("unchecked")
	public List<Employee> editAdminPriv(int empId) {
		Employee employee=getSession().find(Employee.class,empId);
		if(employee.getEmpAdminPrivillages()==0) {
			employee.setEmpAdminPrivillages(1);
		}else {
			employee.setEmpAdminPrivillages(0);
		}
		return getSession().createCriteria(Employee.class).list();
	}

	private Session getSession() {
		Session session = factory.getCurrentSession();
		if (session == null) {
			session = factory.openSession();
		}
		return session;
	}

}
