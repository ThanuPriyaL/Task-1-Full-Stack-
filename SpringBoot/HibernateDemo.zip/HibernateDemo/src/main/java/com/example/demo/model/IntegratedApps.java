package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IntegratedApps")
public class IntegratedApps {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int appId;
	
	private String appName;
	private String appImg;
	private String description;
	private String status;
	private String statusImg;
	
	public IntegratedApps() {}

	public IntegratedApps(int appId, String appName, String appImg, String description, String status,
			String statusImg) {
		super();
		this.appId = appId;
		this.appName = appName;
		this.appImg = appImg;
		this.description = description;
		this.status = status;
		this.statusImg = statusImg;
	}

	public int getAppId() {
		return appId;
	}

	public void setAppId(int appId) {
		this.appId = appId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppImg() {
		return appImg;
	}

	public void setAppImg(String appImg) {
		this.appImg = appImg;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusImg() {
		return statusImg;
	}

	public void setStatusImg(String statusImg) {
		this.statusImg = statusImg;
	}

	@Override
	public String toString() {
		return "IntegratedApps [appId=" + appId + ", appName=" + appName + ", appImg=" + appImg + ", description="
				+ description + ", status=" + status + ", statusImg=" + statusImg + "]";
	}
	
}