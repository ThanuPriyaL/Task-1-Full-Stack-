package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
//@NamedQuery(name="employees.byEmpAdminPrivillages", query="from employees where empAdminPrivillages=?")
@Table(name = "Employees")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "emp_id")
	private int empId;
	@Column(name = "emp_first_name")
	private String empFirstName;
	@Column(name = "emp_last_name")
	private String empLastName;
	@Column(name = "emp_admin_privillages")
	private int empAdminPrivillages;

	public Employee() {
	}

	public Employee(int empId, String empFirstName, String empLastName, int empAdminPrivillages) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empAdminPrivillages = empAdminPrivillages;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public int getEmpAdminPrivillages() {
		return empAdminPrivillages;
	}

	public void setEmpAdminPrivillages(int empAdminPrivillages) {
		this.empAdminPrivillages = empAdminPrivillages;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empAdminPrivillages=" + empAdminPrivillages + "]";
	}
	
	
}
